import re
import requests
import pandas as pd
import time
from tqdm import trange
import bili_pb2
from google.protobuf import text_format


# 视频页面点击“浏览器地址栏小锁-Cookie-bilibili.com-Cookie-SESSDATA”进行获取
SESSDATA = "6fd437ca%2C1684506875%2C09552%2Ab1"
# 视频页面“按F12-Console-输入document.cookie”进行获取
cookie = "buvid3=0F9BAFCF-654A-4630-B613-3EECC8937D67185002infoc; i-wanna-go-back=-1; _uuid=29C96154-5421-7B7A-23DB-2DFA10B105D109266940infoc; buvid4=38CE2317-A117-5288-7485-51D276A2AED969128-022051523-CJBeCHmz7sHpchMvTXx0Ow%3D%3D; nostalgia_conf=-1; CURRENT_BLACKGAP=0; buvid_fp_plain=undefined; bili_jct=3dffc6eb3bd9e98e37148fd57688dd16; DedeUserID=289606321; DedeUserID__ckMd5=3e55ba66656f8fcd; blackside_state=0; b_nut=100; b_ut=5; CURRENT_FNVAL=4048; bsource=search_baidu; rpdid=|(um~u)ll|Y|0J'uYY)mkl~)|; theme_style=light; sid=5zbqxok0; fingerprint=7c705b88e47f4d8bc1439e8b41830217; b_lsid=10789A47C_1849540B253; innersign=1; buvid_fp=0F9BAFCF-654A-4630-B613-3EECC8937D67185002infoc"
cookie += f";SESSDATA={SESSDATA}"
headers = {
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36",
    "cookie": cookie
}

class Reptile:
    def get_info(self,vid):
        url = f"https://api.bilibili.com/x/web-interface/view/detail?bvid={vid}"
        response = requests.get(url, headers=headers)
        response.encoding = "utf-8"
        data = response.json()
        info = {}
        info["标题"] = data["data"]["View"]["title"]
        info["总弹幕数"] = data["data"]["View"]["stat"]["danmaku"]
        info["视频数量"] = data["data"]["View"]["videos"]
        info["cid"] = [dic["cid"] for dic in data["data"]["View"]["pages"]]
        if info["视频数量"] > 1:
            info["子标题"] = [dic["part"] for dic in data["data"]["View"]["pages"]]
        for k, v in info.items():
            print(k + ":", v)
        return info


    def get_danmu(self,info, start, end):    #获取弹幕
        date_list = [i for i in pd.date_range(start, end).strftime("%Y-%m-%d")]
        all_dms = []
        # for i, cid in enumerate(info["cid"]):
        print("为便于展示，本次仅爬取中配版视频弹幕...")
        cid = info["cid"][0]    #第一个视频号
        dms = []
        m = {}      #键值对= 弹幕在视频中出现的时间:弹幕内容
        count = 0
        for j in trange(len(date_list)):
            url = f"https://api.bilibili.com/x/v2/dm/web/history/seg.so?type=1&oid={cid}&date={date_list[j]}"
            response = requests.get(url, headers=headers)

            DATA = response.content
            my_seg = bili_pb2.DmSegMobileReply()
            my_seg.ParseFromString(DATA)
            for j in my_seg.elems:
                parse_data = text_format.MessageToString(j, as_utf8=True)
                tim = re.findall('progress: (.*?)\n', parse_data)
                content = re.findall('content: "(.*?)"\n', parse_data)
                if len(tim) != 0:
                    count += 1
                    if not m.__contains__(tim[0]):  #未存在
                        m[tim[0]] = [content[0]]
                    else:                           #已存在
                        m[tim[0]].append(content[0])
            response.encoding = "utf-8"
            data = re.findall(r"[:](.*?)[@]", response.text)
            dms += [dm[1:] for dm in data]
            time.sleep(3)
        m = sorted(m.items(), key=lambda x:x[0])    #按照键从小到大排序
        f = open(r"/home/hadoop/danmu/src/danmu.txt", mode='w', encoding='utf-8')
        for content in m:
            for i in content[1]:
                f.write(i+'\n')
        f.close()

        # if info["视频数量"] > 1:
        # print("cid:", cid, "弹幕数:", len(dms), "子标题:", info["子标题"][0])
        print("cid:", cid, "弹幕数:", count ,"子标题:", info["子标题"][0])
        all_dms += dms
        # print(f"共获取弹幕{len(all_dms)}条！")
        print(f"共获取弹幕{count}条！")
        return all_dms

    def __init__(self):
        vid = 'BV1AG4y1h7Ap'   # bili的话,手机端打开可看见BV开头的字符串
        info = self.get_info(vid)
        start = "2022-10-27"
        end   = "2022-11-1"
        print("弹幕开始时间（年-月-日）: ",start)
        print("弹幕结束时间（年-月-日）: ",end)
        danmu = self.get_danmu(info, start, end)
        # with open(r"src/danmu.txt", "w", encoding="utf-8") as fout:
        #     for dm in danmu:
        #         fout.write(dm + "\n")
